Open the project via Jupyter Notebook and run
Walkthrough Has been given in report of entire Project
